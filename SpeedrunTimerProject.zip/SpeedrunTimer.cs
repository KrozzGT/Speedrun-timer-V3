using MelonLoader;
using UnityEngine;
using UnityEngine.SceneManagement;
using System.Diagnostics;

public class SpeedrunTimer : MelonMod
{
    private Stopwatch timer = new Stopwatch();
    private bool hasStarted = false;

    public override void OnInitializeMelon()
    {
        SceneManager.sceneLoaded += OnSceneLoaded;
        SceneManager.activeSceneChanged += OnSceneChanged;
    }

    private void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        if (!hasStarted)
        {
            timer.Start();
            hasStarted = true;
        }
        else if (!timer.IsRunning)
        {
            timer.Start();
        }
    }

    private void OnSceneChanged(Scene oldScene, Scene newScene)
    {
        if (timer.IsRunning)
            timer.Stop();
    }

    public override void OnGUI()
    {
        GUIStyle style = new GUIStyle();
        style.fontSize = 40;
        style.fontStyle = FontStyle.Bold;
        style.normal.textColor = Color.white;
        style.alignment = TextAnchor.MiddleCenter;

        float width = 300;
        float height = 80;
        float x = (Screen.width / 2) - (width / 2);
        float y = 20;

        GUI.Label(new Rect(x, y, width, height), timer.Elapsed.ToString(@"hh\:mm\:ss\.fff"), style);
    }
}
