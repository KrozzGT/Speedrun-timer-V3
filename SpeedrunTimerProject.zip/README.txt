READY BUILD PROJECT (PHONE FRIENDLY)

HOW TO BUILD:

1. Upload this folder to Replit (C# project)
2. Create a folder named 'Libs'
3. Put these files inside Libs:
   - MelonLoader.dll
   - UnityEngine.dll
   - UnityEngine.CoreModule.dll

4. Click RUN / BUILD
5. Your DLL will generate

Then move DLL to:
BONELAB/Mods/
